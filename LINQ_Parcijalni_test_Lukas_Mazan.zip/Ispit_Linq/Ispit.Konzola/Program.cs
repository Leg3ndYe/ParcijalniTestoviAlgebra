﻿using System;
using System.Linq;
using Ispit.Model;
using Ispit.Model.Klase;

namespace Ispit.Konzola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Podaci podaci = new Podaci();

            Console.WriteLine("========================================================");
            Console.WriteLine("-----------------------Milijunasi-----------------------");
            Console.WriteLine("========================================================");

            var GrupirajPremaBanci = from milijunas in podaci.ListaKlijenata
                                     where milijunas.Stanje >= 1000000
                                     group milijunas.ImePrezime by milijunas.Banka into grupaBanka
                                     select new GrupiraniMilijunasi()
                                     {
                                         Banka = grupaBanka.Key,
                                         Milijunasi = from milijunas in grupaBanka
                                                      select milijunas
                                     };

            //var GrupirajPremaBanci = podaci.ListaKlijenata.Where(x => x.Stanje > 1000000).GroupBy(x => x.Banka).Select(x => new GrupiraniMilijunasi
            //{
            //    Banka = x.Key,
            //    Milijunasi = x.Select(z => z.ImePrezime)
            //});

            foreach (var simbol in GrupirajPremaBanci)
            {
                Console.Write($"{simbol.Banka}: ");

                int brojMilijunasa = simbol.Milijunasi.Count();

                foreach (var milijunas in simbol.Milijunasi)
                {
                    Console.Write($"{milijunas}");
                    if (brojMilijunasa > 1)
                    {
                        Console.Write(" i ");
                        brojMilijunasa--;
                    }

                }
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("========================================================");
            Console.WriteLine("------------------Izvjestaj Milijunasa------------------");
            Console.WriteLine("========================================================");

            var IzvjestajMilijunasa = from p in podaci.ListaKlijenata
                                      select new
                                      {
                                          ImeClana = p.ImePrezime,
                                          ImeBanke = from b in podaci.ListaBanki
                                                     where b.Simbol == p.Banka
                                                     select b.Naziv
                                      };

            //var IzvjestajMilijunasa = podaci.ListaKlijenata.Select(x => new
            //{
            //    ImeClana = x.ImePrezime,
            //    ImeBanke = podaci.ListaBanki.Where(y => y.Simbol == x.Banka).Select(y => y.Naziv)
            //});

            foreach (var clan in IzvjestajMilijunasa)
            {
                
                foreach(var item in clan.ImeBanke)
                {
                    Console.Write($"{clan.ImeClana} je u {item}");
                    Console.WriteLine();
                }
            }
            Console.WriteLine();
        }
    }
}
