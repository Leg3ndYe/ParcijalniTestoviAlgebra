﻿namespace Ispit.Konzola
{
    internal interface IEqualityComparer<T1, T2>
    {
    }
}