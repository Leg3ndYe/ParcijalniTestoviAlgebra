﻿using Ispit.Model.Klase;

using System.Collections.Generic;

namespace Ispit.Model
{
    public class Podaci
    {
        public List<Banka> ListaBanki = new List<Banka>()
        {
            new Banka() {Simbol = "ZABA",   Naziv = "Zagrebacka Banka"},
            new Banka() {Simbol = "PBZ",    Naziv = "Privredna banka Zagreb"},
            new Banka() {Simbol = "ERSTE",  Naziv = "Erste&Steiermarkische Bank"}
        };

        public List<Klijent> ListaKlijenata = new List<Klijent>()
        {
            new Klijent() {ImePrezime = "Joza Manolic",         Stanje = 25000.00,              Banka = "PBZ"},
            new Klijent() {ImePrezime = "Elon Musk",            Stanje = 69696969696969.00,     Banka = "PBZ"},          //Milijunas 1
            new Klijent() {ImePrezime = "Jeff Bezos",           Stanje = 23451200.00,           Banka = "ZABA"},         //Milijunas 2
            new Klijent() {ImePrezime = "Miroslav Krleza",      Stanje = 4002.00,               Banka = "ERSTE"},
            new Klijent() {ImePrezime = "Mark Zuckerberg",      Stanje = 405666602.00,          Banka = "ERSTE"},        //Milijunas 3
            new Klijent() {ImePrezime = "Ana Karenjnina",       Stanje = 2050.00,               Banka = "PBZ"},
            new Klijent() {ImePrezime = "Pale Kovacic",         Stanje = 5500.00,               Banka = "ZABA"},
            new Klijent() {ImePrezime = "Ranko Karamarko",      Stanje = 3000.00,               Banka = "ERSTE"},
            new Klijent() {ImePrezime = "Spuzva Bob Skockani",  Stanje = 85293.00,              Banka = "ERSTE"},
            new Klijent() {ImePrezime = "Ucitelj Splinter",     Stanje = 23245234.00,           Banka = "PBZ"},

        };
    }
}
