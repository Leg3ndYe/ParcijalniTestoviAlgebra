﻿
namespace Ispit.Model.Klase
{
    public class Klijent
    {
        public string ImePrezime { get; set; }
        public double Stanje { get; set; }  
        public string Banka { get; set; }
    }
}
