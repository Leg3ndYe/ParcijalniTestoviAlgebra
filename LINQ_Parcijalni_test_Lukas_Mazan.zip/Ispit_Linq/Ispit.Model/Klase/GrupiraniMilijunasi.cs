﻿using System.Collections.Generic;

namespace Ispit.Model.Klase
{
    public class GrupiraniMilijunasi
    {
        public string Banka { get; set; }
        public IEnumerable<string> Milijunasi { get; set; }
    }
}
