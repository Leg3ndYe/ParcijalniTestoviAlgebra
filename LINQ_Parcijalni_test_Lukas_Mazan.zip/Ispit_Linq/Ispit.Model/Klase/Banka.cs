﻿
namespace Ispit.Model.Klase
{
    public class Banka
    {
        public string Simbol { get; set; }
        public string Naziv { get; set; }
    }
}
