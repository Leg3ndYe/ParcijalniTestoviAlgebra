﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using aspnet_core_unit_1.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace aspnet_core_unit_1_tests
{
    public class HomeControllerTests
    {
        [Fact]
        public void CheckCountValue_Provjerava_Broj_Metoda_Prvi_Test()
        {
            var controller = new HomeController(null);
            
            var result = controller.CheckCountValue(500);

            Assert.IsAssignableFrom<ViewResult>(result);
        }

        [Fact]
        public void CheckCountValue_Provjerava_Broj_Metoda_Drugi_Test()
        {
            var controller = new HomeController(null);

            var result = controller.CheckCountValue(2);

            Assert.IsAssignableFrom<ViewResult>(result);
        }
    }
}
