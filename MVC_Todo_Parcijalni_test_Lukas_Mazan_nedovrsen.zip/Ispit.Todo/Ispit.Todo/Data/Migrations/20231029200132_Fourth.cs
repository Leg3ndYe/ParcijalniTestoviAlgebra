﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Ispit.Todo.Data.Migrations
{
    /// <inheritdoc />
    public partial class Fourth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "Tasks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.InsertData(
                table: "Todolists",
                columns: new[] { "Id", "Title", "UserId" },
                values: new object[,]
                {
                    { 100, "Vazna lista", "1a3e980b-3d60-42ae-ac13-35775af20431" },
                    { 101, "Lista animea", "1a3e980b-3d60-42ae-ac13-35775af20431" }
                });

            migrationBuilder.InsertData(
                table: "Tasks",
                columns: new[] { "Id", "Description", "IsDone", "TodolistId" },
                values: new object[,]
                {
                    { 1, "Operi sudje", false, 100 },
                    { 2, "Operi ves", false, 100 },
                    { 3, "DragonBall", false, 101 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Todolists",
                keyColumn: "Id",
                keyValue: 100);

            migrationBuilder.DeleteData(
                table: "Todolists",
                keyColumn: "Id",
                keyValue: 101);

            migrationBuilder.DropColumn(
                name: "Description",
                table: "Tasks");
        }
    }
}
