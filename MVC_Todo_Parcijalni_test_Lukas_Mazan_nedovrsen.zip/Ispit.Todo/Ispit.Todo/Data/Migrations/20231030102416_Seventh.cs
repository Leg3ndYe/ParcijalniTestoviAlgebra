﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ispit.Todo.Data.Migrations
{
    /// <inheritdoc />
    public partial class Seventh : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks");

            migrationBuilder.AlterColumn<int>(
                name: "TodolistId",
                table: "Tasks",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateTable(
                name: "TaskList",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TodolistId = table.Column<int>(type: "int", nullable: false),
                    TaskId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TaskList", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TaskList_Tasks_TaskId",
                        column: x => x.TaskId,
                        principalTable: "Tasks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TaskList_Todolists_TodolistId",
                        column: x => x.TodolistId,
                        principalTable: "Todolists",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 1,
                column: "TodolistId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 2,
                column: "TodolistId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 3,
                column: "TodolistId",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_TaskList_TaskId",
                table: "TaskList",
                column: "TaskId");

            migrationBuilder.CreateIndex(
                name: "IX_TaskList_TodolistId",
                table: "TaskList",
                column: "TodolistId");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks",
                column: "TodolistId",
                principalTable: "Todolists",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks");

            migrationBuilder.DropTable(
                name: "TaskList");

            migrationBuilder.AlterColumn<int>(
                name: "TodolistId",
                table: "Tasks",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 1,
                column: "TodolistId",
                value: 100);

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 2,
                column: "TodolistId",
                value: 100);

            migrationBuilder.UpdateData(
                table: "Tasks",
                keyColumn: "Id",
                keyValue: 3,
                column: "TodolistId",
                value: 101);

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks",
                column: "TodolistId",
                principalTable: "Todolists",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
