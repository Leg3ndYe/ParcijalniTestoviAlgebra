﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ispit.Todo.Data.Migrations
{
    /// <inheritdoc />
    public partial class Sixth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Todolists");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "Todolists",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "Todolists",
                keyColumn: "Id",
                keyValue: 100,
                column: "UserId",
                value: "1a3e980b - 3d60 - 42ae - ac13 - 35775af20431");

            migrationBuilder.UpdateData(
                table: "Todolists",
                keyColumn: "Id",
                keyValue: 101,
                column: "UserId",
                value: "1a3e980b - 3d60 - 42ae - ac13 - 35775af20431");
        }
    }
}
