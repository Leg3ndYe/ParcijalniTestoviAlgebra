﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ispit.Todo.Data.Migrations
{
    /// <inheritdoc />
    public partial class Third : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Todolists_UserId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Todolists_Tasks_TodolistId",
                table: "Todolists");

            migrationBuilder.DropIndex(
                name: "IX_Todolists_TodolistId",
                table: "Todolists");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_UserId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "TodolistId",
                table: "Todolists");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "AspNetUsers");

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "Todolists",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "TodolistId",
                table: "Tasks",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Todolists_UserId",
                table: "Todolists",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Tasks_TodolistId",
                table: "Tasks",
                column: "TodolistId");

            migrationBuilder.AddForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks",
                column: "TodolistId",
                principalTable: "Todolists",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Todolists_AspNetUsers_UserId",
                table: "Todolists",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Tasks_Todolists_TodolistId",
                table: "Tasks");

            migrationBuilder.DropForeignKey(
                name: "FK_Todolists_AspNetUsers_UserId",
                table: "Todolists");

            migrationBuilder.DropIndex(
                name: "IX_Todolists_UserId",
                table: "Todolists");

            migrationBuilder.DropIndex(
                name: "IX_Tasks_TodolistId",
                table: "Tasks");

            migrationBuilder.DropColumn(
                name: "TodolistId",
                table: "Tasks");

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "Todolists",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "TodolistId",
                table: "Todolists",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "AspNetUsers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Todolists_TodolistId",
                table: "Todolists",
                column: "TodolistId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_UserId",
                table: "AspNetUsers",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Todolists_UserId",
                table: "AspNetUsers",
                column: "UserId",
                principalTable: "Todolists",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Todolists_Tasks_TodolistId",
                table: "Todolists",
                column: "TodolistId",
                principalTable: "Tasks",
                principalColumn: "Id");
        }
    }
}
