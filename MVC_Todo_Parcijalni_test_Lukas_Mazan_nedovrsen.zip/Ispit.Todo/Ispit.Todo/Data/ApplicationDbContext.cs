﻿using Ispit.Todo.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ispit.Todo.Data
{
    public class AspNetUser : IdentityUser
    {
        [StringLength(100)]
        public string? FirstName { get; set; }
        [StringLength(100)]
        public string? LastName { get; set; }

        [ForeignKey("UserId")]
        public virtual ICollection<Todouserlist> Todouserlists { get; set; }

    }
    public class ApplicationDbContext : IdentityDbContext<AspNetUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Todolist> Todolists { get; set; }
        public DbSet<Ispit.Todo.Models.Task> Tasks { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Todolist>().HasData(new Todolist
            {
                Id = 100,
                Title = "Vazna lista"
            });
            builder.Entity<Todolist>().HasData(new Todolist
            {
                Id = 101,
                Title = "Lista animea"
            });
            builder.Entity<Ispit.Todo.Models.Task>().HasData(new Ispit.Todo.Models.Task
            {
                Id = 1,
                IsDone = false,
                Description = "Operi sudje"
            });
            builder.Entity<Ispit.Todo.Models.Task>().HasData(new Ispit.Todo.Models.Task
            {
                Id = 2,
                IsDone = false,
                Description = "Operi ves"
            });
            builder.Entity<Ispit.Todo.Models.Task>().HasData(new Ispit.Todo.Models.Task
            {
                Id = 3,
                IsDone = false,
                Description = "DragonBall"
            });
            base.OnModelCreating(builder);
        }
    }
}