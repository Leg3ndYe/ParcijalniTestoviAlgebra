﻿using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Reflection.Metadata.Ecma335;

namespace Ispit.Todo.Models
{
    public class TaskList
    {
        [Key]
        public int Id { get; set; }

        public int TodolistId { get; set; }
        public int TaskId { get; set; }
    }
}
