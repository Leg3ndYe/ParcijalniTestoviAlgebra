﻿using Ispit.Todo.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ispit.Todo.Models
{
    public class Todolist
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        [ForeignKey("TodolistId")]
        public virtual ICollection<Ispit.Todo.Models.Task> Tasks { get; set; }

        [ForeignKey("TodolistId")]
        public virtual ICollection<Todouserlist> Todouserlists { get; set; }
        [ForeignKey("TodolistId")]
        public virtual ICollection<TaskList> TaskLists { get; set; }

    }
}
