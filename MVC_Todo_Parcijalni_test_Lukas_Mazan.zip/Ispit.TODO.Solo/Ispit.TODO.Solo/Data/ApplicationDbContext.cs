﻿using Ispit.TODO.Solo.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ispit.TODO.Solo.Data
{
    public class AspNetUser : IdentityUser
    {
        [ForeignKey("UserId")]
        public virtual ICollection<Todolist> Todolist { get; set; }
    }
    public class ApplicationDbContext : IdentityDbContext<AspNetUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Todolist> Todolists { get; set; }
        public DbSet<Models.Task> Tasks { get; set; }
    }
}