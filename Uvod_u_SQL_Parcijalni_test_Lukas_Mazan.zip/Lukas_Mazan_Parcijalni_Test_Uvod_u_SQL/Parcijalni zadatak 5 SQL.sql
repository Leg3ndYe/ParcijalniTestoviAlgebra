Use ZbirkaGlazbeIFilmova;

Update PosudjeniDiskovi 
	Set datPovratka = GetDate()
	where datPovratka is null;

Select	Ime as 'Ime',
		Prezime as 'Prezime',
		isNull(Convert(nvarchar(25), datPovratka), 'Nije vratio') as 'Datum Povratka'
		From PosudjeniDiskovi 
		left join Prijatelji on PosudjeniDiskovi.sifPrijatelja = Prijatelji.sifPrijatelja;
	