Use ZbirkaGlazbeIFilmova;

Select 
	Ime as 'Ime',
	Prezime as 'Prezime',
	IsNull(Convert(nvarchar(25), datPovratka),'Nije jo� vratio/la') as 'Datum povratka',
	DateDiff(day, datPosudbe, GetDate()) as 'Dana pro�lo od posudbe'
	From PosudjeniDiskovi 
	left join Prijatelji on PosudjeniDiskovi.sifPrijatelja = Prijatelji.sifPrijatelja
	where datPovratka is null;
