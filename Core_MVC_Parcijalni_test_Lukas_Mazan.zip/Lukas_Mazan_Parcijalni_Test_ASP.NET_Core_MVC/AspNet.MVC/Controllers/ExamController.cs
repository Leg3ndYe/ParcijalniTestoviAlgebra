﻿using AspNet.MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace AspNet.MVC.Controllers
{
    public class ExamController : Controller
    {
        private readonly ILogger<ExamController> _logger;
        RepositoryAutora _repo;
        public ExamController(ILogger<ExamController> logger)
        {
            _logger = logger;
            _repo = new RepositoryAutora();
        }
        public IActionResult Index()
        {
            List<Book> listaKnjiga = _repo.DohvatiKnjige();
            return View(listaKnjiga);
        }
    }
}
