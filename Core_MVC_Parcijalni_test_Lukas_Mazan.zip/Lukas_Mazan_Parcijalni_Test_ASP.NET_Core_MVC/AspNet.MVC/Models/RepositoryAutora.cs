﻿namespace AspNet.MVC.Models
{
    public class RepositoryAutora
    {
        private static List<Book> listaKnjiga;
        public RepositoryAutora() 
        {
            if(listaKnjiga == null)
            {
                listaKnjiga = new List<Book>();
                DodajAutoreKnjigama();
            }
        }

        private void DodajAutoreKnjigama()
        {
            Author PierceBrown    = new Author() { Ime = "Pierce", Prezime = "Brown",    MjestoRodjenja = "Denver" };
            Author JordanPeterson = new Author() { Ime = "Jordan", Prezime = "Peterson", MjestoRodjenja = "Canada" };
            Author EthanHawke     = new Author() { Ime = "Ethan",  Prezime = "Hawke",    MjestoRodjenja = "Texas" };

            Book RedRising        = new Book() { AuthorKnjige = PierceBrown,    Naziv = "Red Rising",         Zanr = "Znanstvena fantastika" };
            Book GoldenSon        = new Book() { AuthorKnjige = PierceBrown,    Naziv = "Golden Son",         Zanr = "Znanstvena fantastika" };
            Book MorningStar      = new Book() { AuthorKnjige = PierceBrown,    Naziv = "Morning Star",       Zanr = "Znanstvena fantastika" };
            Book RulesForLife     = new Book() { AuthorKnjige = JordanPeterson, Naziv = "12 Rules for Life",  Zanr = "Knjiga za samopomoc" };
            Book RulesForKnight   = new Book() { AuthorKnjige = EthanHawke,     Naziv = "Rules for a Knight", Zanr = "Roman" };

            listaKnjiga.Add(RedRising);
            listaKnjiga.Add(GoldenSon);
            listaKnjiga.Add(MorningStar);
            listaKnjiga.Add(RulesForLife);
            listaKnjiga.Add(RulesForKnight);

        }

        public List<Book> DohvatiKnjige()
        {
            return listaKnjiga;
        }
    }
}
