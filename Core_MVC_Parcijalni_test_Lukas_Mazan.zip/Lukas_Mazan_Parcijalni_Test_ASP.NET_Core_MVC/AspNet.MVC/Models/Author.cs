﻿namespace AspNet.MVC.Models
{
    public class Author
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string MjestoRodjenja { get; set; }
    }
}
