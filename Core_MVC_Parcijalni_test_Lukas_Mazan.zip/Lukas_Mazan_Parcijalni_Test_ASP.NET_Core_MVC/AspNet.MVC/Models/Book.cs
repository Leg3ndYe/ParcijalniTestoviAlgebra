﻿namespace AspNet.MVC.Models
{
    public class Book
    {
        public Author AuthorKnjige { get; set; }
        public string Naziv { get; set; }
        public string Zanr { get; set; }
       
    }
}
