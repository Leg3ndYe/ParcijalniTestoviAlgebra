﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ispit.Model
{
    public class Ucenik
    {
        #region Privatni Clanovi
        private string ime;
        private string prezime;
        private DateTime datumrodjenja;
        private double prosjek;
        #endregion

        #region Svojstva
        /// <summary>
        /// Svojstvo za pristup imenu ucenika.
        /// </summary>
        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        /// <summary>
        /// Svojstvo za pristup prezimenu ucenika.
        /// </summary>
        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }
        /// <summary>
        /// Svojstvo za pristup datumu rodjenja ucenika.
        /// </summary>
        public DateTime Datumrodjenja
        {
            get { return datumrodjenja; }
            set { datumrodjenja = value; }
        }
        /// <summary>
        /// Svojstvo za pristup prosjeku ucenika.
        /// </summary>
        /// <exception cref="ArgumentException">Iznimka ukoliko se postavi vrijednost ispod 1.0 ili iznad 5.0</exception>
        public double Prosjek
        {
            get { return prosjek; }
            set 
            {
                if (value < 1 || value > 5) throw new ArgumentException("Prosjek ne moze biti ispod 1 ili iznad 5. Krivi unos!");
                prosjek = value;
            }
        }
        #endregion

        #region Metode
        /// <summary>
        /// Vraca objekt Ucenik s imenom, prezimenom, datumom rodjenja i prosjekom.
        /// </summary>
        /// <returns></returns>
        public static Ucenik UnosPodataka()
        {
            Console.Write("Unesite svoje ime: ");
            string ime = Console.ReadLine();
            Console.Write("Unesite svoje prezime: ");
            string prezime = Console.ReadLine();
            Console.Write("Unesite svoj datum rodjenja (dd/MM/yyyy): ");
            DateTime datumrodjenja = DateTime.ParseExact(Console.ReadLine(), "dd.MM.yyyy", CultureInfo.InvariantCulture);
            Console.Write("Unesite prosjek ocjena: ");
            double prosjek = Convert.ToDouble(Console.ReadLine());

            Ucenik ucenik = new Ucenik(ime, prezime, datumrodjenja, prosjek);

            return ucenik;
        }
        /// <summary>
        /// Vraca starosnu dob Ucenika(godine).
        /// </summary>
        /// <param name="datumrodjenja"></param>
        /// <returns></returns>
        public static long Starost(DateTime datumrodjenja)
        {
            long godine = 0;
            TimeSpan starost = new TimeSpan(DateTime.Now.Ticks - datumrodjenja.Ticks);
            godine = (long)(starost.Days / 365);
            return godine;      
        }
        /// <summary>
        /// Vraca ocjenu Ucenika.
        /// </summary>
        /// <param name="prosjek"></param>
        /// <returns></returns>
        public static string IspisProsjeka(double prosjek)
        {
            string ocjena = "";
            if (prosjek >= 1 && prosjek <= 1.49f) ocjena = "Nedovoljan";
            else if (prosjek >= 1.50f && prosjek <= 2.49f) ocjena = "Dovoljan";
            else if (prosjek >= 2.50f && prosjek <= 3.49f) ocjena = "Dobar";
            else if (prosjek >= 3.50f && prosjek <= 4.49f) ocjena = "Vrlo Dobar";
            else if (prosjek >= 4.50f && prosjek <= 5f) ocjena = "Odlican";
            return ocjena;
        }
        public override string ToString()
        {
            return string.Format($"Ime i Prezime : {ime} {prezime}" + Environment.NewLine +
                                 $"Starost: {Starost(datumrodjenja)} " + Environment.NewLine +
                                 $"Ocjena: {IspisProsjeka(prosjek)}" + Environment.NewLine +
                                 $"Prosjek: {prosjek}");
        }
        #endregion

        #region Konstruktori
        public Ucenik() { }
        public Ucenik(string ime, string prezime, DateTime datumrodjena, double prosjek)
        {
            Ime = ime;
            Prezime = prezime;
            Datumrodjenja = datumrodjena;
            Prosjek = prosjek;
        }
        #endregion
    }
}
