﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ispit.Model;

namespace Ispit.Konzola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ucenik ucenik1 = Ucenik.UnosPodataka();
            Console.WriteLine();
            Ucenik ucenik2 = Ucenik.UnosPodataka();
            Console.WriteLine();
            Ucenik ucenik3 = Ucenik.UnosPodataka();
            Console.WriteLine();

            Console.WriteLine(ucenik1);
            Console.WriteLine();

            Console.WriteLine(ucenik2);
            Console.WriteLine();

            Console.WriteLine(ucenik3);
            Console.WriteLine();
        }
       

    }
}
