﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EF_CodeFirst.Models
{
    public class Grade
    {
        [Key]
        public int GradeID { get; set; }
        [DisplayName("Ocjena")]
        public string GradeName { get; set; }
        [DisplayName("Predmet")]
        public string Section { get; set; }
        [ForeignKey("StudentID")]
        [DisplayName("Student")]
        public int StudentID { get; set; }
    }
}
