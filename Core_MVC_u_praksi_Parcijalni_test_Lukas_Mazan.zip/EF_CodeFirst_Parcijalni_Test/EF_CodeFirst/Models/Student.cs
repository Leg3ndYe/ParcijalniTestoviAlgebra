﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EF_CodeFirst.Data
{
    public class Student
    {
        [Key]
        public int StudentID { get; set; }
        [DisplayName("Ime studenta")]
        public string StudentName { get; set; }
        [DisplayName("Datum rodjenja")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
        [DisplayName("Visina")]
        public decimal Height { get; set; }
        [DisplayName("Kilaza")]
        public float Weight { get; set; }
    }
}
