﻿using EF_CodeFirst.Models;
using Microsoft.EntityFrameworkCore;

namespace EF_CodeFirst.Data
{
    public class CodeFirstContext:DbContext
    {
        public CodeFirstContext(DbContextOptions<CodeFirstContext> options) : base(options) { }

        public DbSet<Student> Student { get; set; }
        public DbSet<Grade> Grade { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().HasData(
                new Student { StudentID=1, StudentName="Stjepan", DateOfBirth=new DateTime(2002, 6, 17), Height=180, Weight= 90},
                new Student { StudentID = 2, StudentName = "Dora", DateOfBirth = new DateTime(2006, 2, 3), Height = 160, Weight = 50 }
                );
            modelBuilder.Entity<Grade>().HasData(
                new Grade { GradeID = 1, GradeName="Nedovoljan", Section="", StudentID = 1},
                new Grade { GradeID = 2, GradeName = "Dovoljan", Section = "", StudentID = 1 },
                new Grade { GradeID = 3, GradeName = "Dobar", Section = "", StudentID = 2 },
                new Grade { GradeID = 4, GradeName = "Vrlo Dobar", Section = "", StudentID = 1 },
                new Grade { GradeID = 5, GradeName = "Odlican", Section = "", StudentID = 2 },
                new Grade { GradeID = 6, GradeName = "Vrlo Odlican", Section = "", StudentID = 1 },
                new Grade { GradeID = 7, GradeName = "Super Vrlo Odlican", Section = "", StudentID = 2 }
                );
        }

    }
}
