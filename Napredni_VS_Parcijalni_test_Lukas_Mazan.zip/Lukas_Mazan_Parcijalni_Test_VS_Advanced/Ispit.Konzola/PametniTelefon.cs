﻿using Ispit.Konzola.Sucelja;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace Ispit.Konzola
{
    class PametniTelefon : IPametniTelefon, ITelefon
    {
        public string Model { get; private set; }
        public PametniTelefon(string model)
        {
            Model = model;
        }
        public string Surfanje(string url)
        {
            try
            {
                if (ProvjeriAkoJeValidanUrl(url))
                {
                    return "Moguce je surfati na ovom URL-u! \n"+
                        "Surfam na: ";
                }
                else
                {
                    return "Neispravan URL! ";
                }
            }
            catch (Exception ex)  
            {
                return ex.Message + "Doslo je do pogreske kod unosa URL-a!";
            }
        }
        public string Poziv(string telefonski_broj)
        {
            try
            {
                if((telefonski_broj.Length <= 10) && ProvjeriAkoJeValidanBroj(telefonski_broj))
                {
                    return "Moguce je zvati taj telefonski broj!\n"+
                        "Evo zovem... ";
                }
                else
                {
                    return "Neispravan telefonski broj! ";
                }
            }
            catch (Exception ex)
            {
                return ex.Message + " Doslo je do pogreske kod unosa telefonskog broja!";
            }
        }
        public bool ProvjeriAkoJeValidanUrl(string url)
        {
            bool urlSadrziBroj = url.Any(x => char.IsDigit(x));
            if (!urlSadrziBroj) return true;
            else return false;
        }
        public bool ProvjeriAkoJeValidanBroj(string telefonski_broj)
        {
            bool mozeZvati = telefonski_broj.All(x => char.IsDigit(x));
            if (mozeZvati) return true;
            else return false;
        }
    }
}
