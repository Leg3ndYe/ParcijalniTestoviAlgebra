﻿using Ispit.Konzola.Sucelja;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ispit.Konzola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PametniTelefon smartPhone = new PametniTelefon("Nokia3310");

            TestirajTelefon(smartPhone);
        }
        public static void TestirajTelefon(PametniTelefon telefon)
        {
            Console.Write("Koji broj da zovem? ");
            string telefonski_broj = Console.ReadLine();
            Console.Write("Koju web stranicu da posjetim? ");
            string url = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine(telefon.Model);
            Console.WriteLine();
            Console.WriteLine(telefon.Poziv(telefonski_broj) + telefonski_broj);
            Console.WriteLine();
            Console.WriteLine(telefon.Surfanje(url) + url);
            Console.WriteLine();
        }
    }
}
