﻿using Microsoft.AspNetCore.Mvc;
using Ispit.Data.Models;
using Ispit.Data.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Ispit.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IspitRepositoryController : ControllerBase
    {
        private readonly IIspit _ispitRepository;
        public IspitRepositoryController(IIspit ispitRepository)
        {
            _ispitRepository = ispitRepository;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Data.Models.Ispit>> GetTests()
        {
            try
            {
                return Ok(_ispitRepository.GetAll());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving data from the database");
            }
        }

        [HttpGet("{id}")]
        public ActionResult<Data.Models.Ispit> GetTest(int id)
        {
            try
            {
                var test = _ispitRepository.GetById(id);
                if (test == null) return NotFound();
                return Ok(test);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving data from the database");
            }
        }

        [HttpPost]
        public ActionResult<Data.Models.Ispit> PostTest([FromBody] Data.Models.Ispit test)
        {
            try
            {
                if (!ModelState.IsValid) return BadRequest(ModelState);
                var newTest = _ispitRepository.Add(test);
                return CreatedAtAction(nameof(GetTest), new { id = newTest.Id }, newTest);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error creating new test.");
            }
        }

        [HttpPut("{id}")]
        public ActionResult<Data.Models.Ispit> PutTest(int id, Data.Models.Ispit test)
        {
            try
            {
                if (id != test.Id) return BadRequest("Test ID mismatch.");

                var testToUpdate = _ispitRepository.GetById(id);

                if (testToUpdate == null) return NotFound("Test to update was not found.");

                return Ok(_ispitRepository.Update(test));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error updating test.");
            }
        }

        [HttpDelete("{id}")]
        public ActionResult<Data.Models.Ispit> DeleteTest(int id)
        {
            try
            {
                var testToDelete = _ispitRepository.GetById(id);
                if (testToDelete == null) return BadRequest("Test to delete not found.");

                return Ok(_ispitRepository.Delete(id));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error deleting test.");
            }
        }
        
    }
}
