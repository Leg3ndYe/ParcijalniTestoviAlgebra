﻿using Ispit.Data.Interfaces;
using Ispit.Data.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ispit.Data.Repository
{
    public class IspitRepository : IIspit
    {
        private readonly IspitContext _context;
        public IspitRepository(IspitContext context)
        {
            _context = context;
        }
        public Models.Ispit Add(Models.Ispit ispit)
        {
            var noviIspit = _context.Ispiti.Add(new Models.Ispit
            {
                Title = ispit.Title,
                Description = ispit.Description,
                IsCompleted = ispit.IsCompleted
            });
            _context.SaveChanges();
            return noviIspit.Entity;
        }

        public Models.Ispit Delete(int id)
        {
            var ispit = _context.Ispiti.Find(id);
            if(ispit == null)
            {
                return null;
            }
            _context.Ispiti.Remove(ispit);
            _context.SaveChanges();
            return ispit;
        }

        public IEnumerable<Models.Ispit> GetAll()
        {
            return _context.Ispiti.ToList();
        }

        public Models.Ispit GetById(int id)
        {
            return _context.Ispiti.Find(id);
        }

        public Models.Ispit Update(Models.Ispit ispit)
        {
            var test = _context.Ispiti.Find(ispit.Id);
            if(test != null)
            {
                test.Title = ispit.Title;
                test.Description = ispit.Description;
                test.IsCompleted = ispit.IsCompleted;
                _context.SaveChanges();
                return test;
            }
            return null;
        }
    }
}
