﻿using System.ComponentModel.DataAnnotations;

namespace Ispit.Data.Models
{
    public class Ispit
    {
        [Key]
        public int Id { get; set; }

        [StringLength(150, MinimumLength = 2)]
        public string Title { get; set; }

        [StringLength(500, MinimumLength = 2)]
        public string Description { get; set; }
        
        public bool IsCompleted { get; set; }
    }
}
