﻿using Ispit.Data.Repository;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ispit.Data.Models
{
    public partial class IspitContext:DbContext
    {
        public IspitContext()
        {
        }

        public IspitContext(DbContextOptions<IspitContext> options):base(options)
        {

        }
        public virtual DbSet<Ispit> Ispiti { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DESKTOP-LUKAS\\SQLEXPRESS;database=IspitAPIDB;" + 
                    "integrated security = true; MultipleActiveResultSets = true; TrustServerCertificate = true; ");
            }
        }
    }
}
