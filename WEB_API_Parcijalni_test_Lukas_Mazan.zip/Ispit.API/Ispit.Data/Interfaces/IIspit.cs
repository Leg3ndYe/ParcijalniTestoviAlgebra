﻿using Ispit.Data.Models;

namespace Ispit.Data.Interfaces
{
    public interface IIspit
    {
        IEnumerable<Models.Ispit> GetAll();
        Models.Ispit GetById(int id);
        Models.Ispit Add(Models.Ispit ispit);
        Models.Ispit Update(Models.Ispit ispit);
        Models.Ispit Delete(int id);
    }
}
